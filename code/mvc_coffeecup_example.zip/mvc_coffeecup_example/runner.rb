require_relative 'controller.rb'
require_relative 'view.rb'
require_relative 'coffee_cup.rb'

Controller.new
